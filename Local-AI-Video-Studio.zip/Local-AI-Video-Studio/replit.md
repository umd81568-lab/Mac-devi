# Local AI Studio

Local-first production workspace for planning and delivering professional AI video, voice, and realistic human-presenter avatar projects.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/local-ai-studio/src/` — responsive production workspace UI and route-level screens
- `artifacts/api-server/src/routes/studio.ts` — studio overview, projects, plans, readiness, models, providers, and render queue API
- `lib/api-spec/openapi.yaml` — source of truth for the studio API contract
- `lib/db/src/schema/` — PostgreSQL tables for projects, plans, models, providers, render jobs, and activity

## Architecture decisions

- The web control surface is local-first and keeps optional remote inference providers separate from the local runtime.
- The local Mac worker is represented by an explicit desktop-bridge readiness state; the server must not claim that a remote preview environment is the user's Mac.
- Human-presenter/avatar workflows are the product focus; cartoon or mascot avatar concepts are intentionally outside the product surface.
- Hugging Face is modeled as an optional provider connection and must not expose token values in project data or activity logs.
- Long-running model installs and renders are queue states so a future native worker can resume them without changing the API contract.

## Product

Local AI Studio gives creators a command center for production projects, script-to-scene planning, local model readiness, professional voice routing, realistic human-avatar workflows, and render queue management. It is designed for Apple Silicon Macs with a 64GB unified-memory profile.

## User preferences

- The user requires a professional, fully functional product rather than a demo interface.
- The user explicitly does not want cartoon/avatar-character projects.

## Gotchas

- The API contract must be regenerated after every OpenAPI change.
- Generated Zod output in this workspace currently maps OpenAPI `number` safely; avoid `integer` schemas because the installed Zod runtime does not expose `zod.int()`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
