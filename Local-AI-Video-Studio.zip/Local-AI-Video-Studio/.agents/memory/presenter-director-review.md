---
name: Presenter director review gate
description: Completion semantics for local human presenter output.
---

Worker-uploaded presenter video must enter a review state after technical media checks and subtitle processing. It must not be treated as a completed presenter delivery, or be eligible for final composition, until a director explicitly approves it.

**Why:** Container/audio/motion checks can establish limited technical facts but cannot independently prove realistic human identity, correct reference use, or natural speech-synchronized performance. Marking that output complete would overclaim what the system can verify.

**How to apply:** Preserve the separate review state and an explicit approval action whenever presenter output verification changes. User-facing copy must call it a candidate until approval, not a verified human delivery.