---
name: MLX presenter runtime pinning
description: The local human presenter must be reproducible and capability-gated on a managed Apple Silicon runtime.
---

The presenter runtime and model revision should be pinned together, installed in a dedicated macOS virtualenv, and exposed to the signed worker only after a real MP4/audio/motion self-check passes.

**Why:** Ambient Python packages and mutable model downloads can make the worker advertise readiness for a pipeline that cannot actually reproduce or verify a human performance.

**How to apply:** Keep model download, runtime imports, media muxing, and local non-static verification inside the managed presenter installation; preserve an explicit blocked state when any prerequisite is missing.

For selectable precision variants, persist an allowlisted manifest containing the
variant, runtime loader key, model repository, exact revision, weights
directory, and runtime commit. Validate the runtime's variant-to-directory map
and the installed model's quantization metadata before reporting readiness.

**Why:** A model directory name or user-edited manifest alone cannot prove that
the selected runtime loader will load the intended precision; a mixed q4/bf16
install must be visibly blocked rather than falling back.

**How to apply:** Add every supported variant to the installer and adapter
allowlists together. Keep the worker's readiness label sourced from the
adapter's validated manifest output, not from an inferred directory name.