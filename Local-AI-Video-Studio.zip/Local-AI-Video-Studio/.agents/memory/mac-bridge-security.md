---
name: Mac bridge security boundary
description: Durable constraints for the local Mac worker pairing and credential flow.
---

The Mac bridge treats the currently paired worker as the only command recipient, authenticates requests with nonce-based HMAC, expires liveness quickly, and never accepts a Hugging Face token through the Studio API.

**Why:** The studio can coordinate local setup without becoming a credential store or allowing a stale worker to keep receiving model commands.

**How to apply:** Keep pairing secrets short-lived, reject replayed nonces and stale workers, require explicit install approval, and report only Keychain storage confirmation for provider credentials.