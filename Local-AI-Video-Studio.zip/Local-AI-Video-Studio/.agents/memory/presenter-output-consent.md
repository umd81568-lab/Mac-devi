---
name: Presenter output consent provenance
description: Trust boundary for consent metadata on generated human-presenter outputs.
---

Persisted presenter-output consent metadata must be derived from the server's stored, consented real-human reference rather than copied from worker-supplied claims. Regression fixtures should bind the reference and output proof to a pinned content digest.

**Why:** A valid worker signature proves which paired worker sent a response, but it does not make worker-authored consent claims authoritative or prove which reference media was used.

**How to apply:** On presenter output acceptance, re-check the referenced asset's consent and real-human classification, persist its server-held identity and digest, and test unsigned and replayed requests for non-mutation.