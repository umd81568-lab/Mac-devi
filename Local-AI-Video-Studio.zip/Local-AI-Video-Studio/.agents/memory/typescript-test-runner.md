---
name: TypeScript test runner
description: Environment constraint for running TypeScript tests in workspace packages.
---

API package tests must run through the workspace-installed tsx runner rather than Node's native type stripping. Native stripping can parse the test files but fails on the repository's extensionless TypeScript workspace imports (for example, the database package's schema directory import).

**Why:** The workspace packages use bundler-style extensionless imports and expose TypeScript source directly; Node's ESM resolver does not apply the same resolution rules.

**How to apply:** Keep API test commands on the existing workspace tsx installation and use `.js` specifiers in test source so the package typecheck remains compatible with the production module settings.