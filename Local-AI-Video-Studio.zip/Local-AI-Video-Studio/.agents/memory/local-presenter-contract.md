---
name: Local presenter generation contract
description: Rules for keeping realistic human-presenter generation local, honest, and verifiable.
---

The presenter path must be capability-gated on a signed Apple Silicon worker with Metal/MPS, MLX, and an installed local human-performance pipeline. A job may not fall back to a still image, audio-only output, or decorative motion.

**Why:** A successful job status is user-facing proof that a real human performance was generated, so pretending a missing model worked is worse than a visible blocked or failed job.

**How to apply:** Keep consented real-human references, framing/delivery settings, progress/errors, and runtime requirements persisted. Require server-side MP4/audio/duration/motion verification and preserve explicit worker failures through previews and final scene renders.